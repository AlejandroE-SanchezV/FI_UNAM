public interface RadianesGrados {
    void radAGrad();
}