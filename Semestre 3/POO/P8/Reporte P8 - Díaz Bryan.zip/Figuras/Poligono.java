public abstract class Poligono {
    public double area(){
		return 0d;
	}

	public double perimetro(){
		return 0d;
	}

	public String toString(){
		return "Poligono";
	}   
}