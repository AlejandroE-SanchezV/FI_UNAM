public interface GradosRadianes {
    void gradARad();
}