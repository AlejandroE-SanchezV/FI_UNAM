package biblioteca.libro;

import usuario.Persona;

public class Autor extends Persona{
	int idAutor;
	int numLibros;

	public Autor(String n, String ap, String am, int num){
		super(n, ap, am);
		numLibros = num;
	}

	public Autor(){}

	public void setIdAutor(int id){
		idAutor = id;
	}

	public void setNumLibros(int num){
		numLibros = num;
	}

	public int getIdAutor(){
		return idAutor;
	}

	public int getNumLibros(){
		return numLibros;
	}
}