package biblioteca;

import biblioteca.libro.Libro;

class LibroBiblioteca{
  String clave;
  String ubicacion;
  Libro libro;

  /*LibroBiblioteca(String c, String u, String titulo, String fechaPublicacion){
    clave = c;
    ubicacion = u;
    libro = new Libro(titulo, fechaPublicacion);
  }*/

  LibroBiblioteca(String c, String u, Libro l){
    clave = c;
    ubicacion = u;
    libro = l;
  }

  public void setClave(String c){
    clave = c;
  }

  public void setUbicacion(String u){
    ubicacion = u;
  }

  public void setLibro(Libro l){
    libro = l;
  }

  /*public void setLibro(String titulo, String fechaPublicacion){
    libro = new Libro(titulo, fechaPublicacion);
  }*/

  public String getClave(){
    return clave;
  }

  public String getUbicacion(){
    return ubicacion;
  }

  public Libro getLibro(){
    return libro;
  }
}
