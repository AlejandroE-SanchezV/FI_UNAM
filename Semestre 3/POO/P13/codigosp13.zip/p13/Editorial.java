package biblioteca.libro;

public class Editorial{
  int idEditorial;
  String nombre;

  public Editorial(String nombre){
    this.nombre = nombre;
  }

  public Editorial(){}

  public void setIdEditorial(int id){
    idEditorial = id;
  }

  public void setNombre(String n){
    nombre = n;
  }

  public int getIdEditorial(){
    return idEditorial;
  }

  public String getNombre(){
    return nombre;
  }
}
