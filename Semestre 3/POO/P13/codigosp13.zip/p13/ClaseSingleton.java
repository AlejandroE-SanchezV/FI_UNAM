public class ClaseSingleton{
	private static ClaseSingleton cs;
	private String info;
	
	private ClaseSingleton(String nombre){
		info = "Hola " + nombre;
	}

	public static ClaseSingleton getInstance(String nombre){
		if(cs == null) cs = new ClaseSingleton(nombre);
		return cs;
	}

	public String getInfo(){
		return info;
	}
}