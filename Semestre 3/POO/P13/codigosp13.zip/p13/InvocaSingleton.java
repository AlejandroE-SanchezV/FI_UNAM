public class InvocaSingleton{
	public static void main(String[] args) {
		ClaseSingleton cs1 = ClaseSingleton.getInstance("Liz");

		System.out.println(cs1.getInfo());

		ClaseSingleton cs2 = ClaseSingleton.getInstance("Lupita");

		System.out.println(cs2.getInfo());

		ClaseSingleton cs3 = ClaseSingleton.getInstance("Parrales");

		System.out.println(cs3.getInfo());
	}
}