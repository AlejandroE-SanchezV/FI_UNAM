package biblioteca.libro;

public class Libro{
  int idLibro;
  String nombre;
  String fechaPublicacion;
  Autor autor;
  Editorial ed;

  public Libro(String n, String f, Editorial e){
    nombre = n;
    fechaPublicacion = f;
    ed = e;
  }

  public Libro(){}

  public void setIdLibro(int id){
    idLibro = id;
  }

  public void setNombre(String n){
    nombre = n;
  }

  public void setFechaPublicacion(String f){
    fechaPublicacion = f;
  }

  public void setEditorial(Editorial e){
    ed = e;
  }

  public void setAutor(Autor a){
    autor = a;
  }

  public int getIdLibro(){
    return idLibro;
  }

  public String getNombre(){
    return nombre;
  }

  public String getFechaPublicacion(){
    return fechaPublicacion;
  }

  public Editorial getEditorial(){
    return ed;
  }

  public Autor getAutor(){
    return autor;
  }

}
